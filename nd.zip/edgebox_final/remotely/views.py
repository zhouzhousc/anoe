from django.http import JsonResponse
from django.shortcuts import render
from .models import get_settingdown_model

# Create your views here.
# /apis/log/list
def List(request):
    """
    用于提供設備列表数据
    :param request: HttpRequest
    :return: Json
    """
    if request.method == "GET":
        # db = [{"content":i["create_time"].strftime("%H:%M:%S  ")+i["remark"], "timestamp":i["create_time"].strftime("%Y-%m-%d")} for i in row_last_data]
        obj = get_settingdown_model.objects.all().values()
        db = [ i for i in obj]
        return JsonResponse({
            "status_code": 0,
            "db": db
        })
