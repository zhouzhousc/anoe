from django.apps import AppConfig


class RemotelyConfig(AppConfig):
    name = 'remotely'
