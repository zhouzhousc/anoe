import json

import datetime, time

from django.shortcuts import render

# Create your views here.
from django_redis import get_redis_connection
from plugins.systemos import systemos

from plugins.auth_corepro import AuthCorepro as agentauth
from Device.models import SubDevice
from .models import RegisterInfo
from django.http import JsonResponse
from django.core import serializers
import psutil


# /apis/agent/info
def Info(request):
    """
    用于提供Agent数据
    :param request: HttpRequest
    :return: Json
    """
    def auth():
        result =agentauth(ProductKey= vue_json["gateway_key"],
                  DeviceName= vue_json["gateway_name"],
                  DeviceSecret= vue_json["gateway_secret"],
                  auth_url= vue_json["gateway_tokenapi"])
        return [result.username, result.password, result.mqtthost, result.mqttport ]

    if request.method == "POST":
        try:
            vue_json = json.loads(request.body.decode())["params"]
            # print(vue_json)
            result = auth()
            if all(result):
                obj, created = RegisterInfo.objects.update_or_create(
                    gateway_trade_name='IoT',
                    gateway_model='IoT',
                    gateway_remark="EdgeBox边缘层网关测试版",
                    gateway_key=vue_json["gateway_key"],
                    gateway_secret=vue_json["gateway_secret"],
                    gateway_tokenapi=vue_json["gateway_tokenapi"],
                    gateway_location=vue_json["gateway_location"],
                    gateway_iotid=result[0],
                    gateway_iottoken=result[1],
                    gateway_iothost=result[2],
                    gateway_iotport=result[3],
                    gateway_registration_time = datetime.datetime.now(),
                    defaults={"gateway_name" : vue_json["gateway_name"]},
                )
                status = "新建" if created else '修改'
                conn = get_redis_connection('default')
                conn.hset("Agent", "name", vue_json["gateway_name"])
                conn.hset("Agent", "id", vue_json["gateway_key"])
                conn.hset("Agent", "sercet", vue_json["gateway_secret"])
                conn.hset("Agent", "tokenapi", vue_json["gateway_tokenapi"])
                conn.hset("Agent", "location", vue_json["gateway_location"])

                return JsonResponse({
                    "status_code": 0,
                    "message": "注册成功/"+ status,
                })
            else:
                return JsonResponse({
                    "status_code": 1,
                    "error": "注册修改出错: auth error",
                })
        except Exception as e:

            return JsonResponse({
                "status_code": 1,
                "error": "注册修改出错:"+str(e),
            })

    if request.method == "GET":

        # data = RegisterInfo.objects.create(gateway_name="EdgeBox003",
        #                                    gateway_key="6553791093879608705",
        #                                    gateway_secret="e3f3eeb045f0a19284ad03f64e101ce3f7fa15d135a7140e411fa29dbd269d7c",
        #                                    gateway_subdevice_num=0,
        #                                    gateway_model="IoT",
        #                                    gateway_trade_name="IoT",
        #                                    gateway_registration_time=datetime.datetime.now(),
        #                                    gateway_location="E5-4F",
        #                                    gateway_remark="EdgeBox边缘层网关测试版")
        # data.save()
        # row_data = RegisterInfo.objects.all().values()[0]
        raw_data = RegisterInfo.objects.all().order_by("-id").values()[:4]
        row_data = raw_data[0]
        row_data['gateway_registration_time'] = row_data['gateway_registration_time'].strftime("%Y-%m-%d %H:%M:%S")
        row_data["gateway_subdevice_num"] = SubDevice.objects.all().count()
        row_data["status_code"] = 0
        history_data = raw_data[1:4]
        history_data = [ data for data in history_data]
        return JsonResponse({
                "row_data": [row_data],
                "history_data": history_data,
            })


# /apis/agent/sysinfo
def sysInfo(request):
    """
    用于提供数据
    :param request: HttpRequest
    :return: Json
    """

    if request.method == "GET":
        data = {}
        s = systemos()
        if request.GET.get("cpu") is not None:
            data["data_for_cpu"]= s.GetCpuInfo()
        elif request.GET.get("os") is not None:
            data["data_for_sys"]= s.GetMemoryInfo()
        elif  request.GET.get("interface") is not None:
            data["data_for_disk"]= s.GetDiskInfo()
        data["status_code"] = 0
        data["cpu_status"] = max(psutil.cpu_percent(interval=1, percpu=True))  # 获得cpu当前使用率
        data["memory_status"] = float(psutil.virtual_memory().percent)  # 获取当前内存使用情况
        data["disk_status"] = float(psutil.disk_usage("/").percent)  # 获取当前磁盘的使用率
        return JsonResponse(data)
