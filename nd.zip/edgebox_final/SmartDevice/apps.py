from django.apps import AppConfig


class SmartdeviceConfig(AppConfig):
    name = 'SmartDevice'
